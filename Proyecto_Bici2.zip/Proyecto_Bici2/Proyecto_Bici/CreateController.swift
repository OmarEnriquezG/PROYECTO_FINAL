//
//  CreateController.swift
//  Proyecto_Bici
//
//  Created by macbook  on 11/15/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit
import Firebase

class CreateController: UIViewController {
    @IBOutlet weak var Nombre: UITextField!
    @IBOutlet weak var Password: UITextField!
    @IBOutlet weak var Email: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
   
    @IBAction func Crear(_ sender: UIButton)
    {
        guard let correo = Email.text,
            let pass = Password.text,
            let username = Nombre.text else {return}
            print(correo)
        Auth.auth().createUser(withEmail: correo, password: pass) { (data, error) in
            if let error = error{
                debugPrint(error.localizedDescription)
            }
           
            let user = data
            let changeRequest = user?.createProfileChangeRequest()
            changeRequest?.displayName = username
            changeRequest?.commitChanges(completion: { (error) in
                if let error = error{
                    debugPrint(error.localizedDescription)
                }
            })
            
            guard let userId = user?.uid else { return }
            Firestore.firestore().collection("users").document(userId).setData([
                "username" : username,
                "date_created": FieldValue.serverTimestamp()
                ], completion: { (error) in
                    if let error = error {
                        debugPrint(error)
                    }else{
                        self.navigationController?.popViewController(animated: true)
                    }
            })
        }
        
 
   
    

}
    @IBAction func Back(_ sender: UIButton) {
        
        navigationController?.popViewController(animated: true)
    }
}
