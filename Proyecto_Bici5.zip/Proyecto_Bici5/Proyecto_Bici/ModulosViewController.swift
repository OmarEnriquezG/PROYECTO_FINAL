//
//  ModulosViewController.swift
//  Proyecto_Bici
//
//  Created by macbook  on 11/15/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit


class ModulosViewController: UIViewController, UITableViewDataSource, UITableViewDelegate{
    

    var modules = [modulos]()
    var myindex = 0
    

    @IBOutlet weak var mapa: MKMapView!
    @IBOutlet weak var tabla: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()

        modules.append(modulos(nombre: "Universidad", latitude: 19.325203, longitude: -99.174788))
        modules.append(modulos(nombre: "Facultad de Ciencias", latitude: 19.325146, longitude: -99.178884))
        modules.append(modulos(nombre: "Anexo de Ingeniería", latitude: 19.327874, longitude: -99.182928))
        modules.append(modulos(nombre: "Facultad de Ingeniería", latitude: 19.332143, longitude: -99.184406))
        
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return modules.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        
        cell.textLabel?.text = modules[indexPath.row].nombre
        
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        myindex = indexPath.row
        let annotation = Annotation()
        if myindex == 0 {
            annotation.coordinate = CLLocationCoordinate2D(latitude: 19.325203, longitude: -99.174788)
            annotation.title = "Universidad"
            annotation.subtitle = "Ciudad Universitaria"
            annotation.imageURL = "icono"
            
            mapa.addAnnotation(annotation)
        }
        else if myindex == 1 {
            annotation.coordinate = CLLocationCoordinate2D(latitude: 19.325146, longitude: -99.178884)
            annotation.title = "Facultad de Ciencias"
            annotation.subtitle = "Ciudad Universitaria"
            annotation.imageURL = "icono"
            
            mapa.addAnnotation(annotation)
            
            }
        else if myindex == 2{
            annotation.coordinate = CLLocationCoordinate2D(latitude: 19.327874, longitude: -99.182928)
            annotation.title = "Anexo de Ingenieria"
            annotation.subtitle = "Ciudad Universitaria"
            annotation.imageURL = "icono"
            
            mapa.addAnnotation(annotation)
            
        }
        else if myindex == 3{
            annotation.coordinate = CLLocationCoordinate2D(latitude: 19.332143, longitude: -99.184406)
            annotation.title = "Facultad de Ingeniería"
            annotation.subtitle = "Ciudad Universitaria"
            annotation.imageURL = "icono"
            
            mapa.addAnnotation(annotation)
            
        }
        }
        
        
    }
    
    
            
            
            

