//
//  LoginViewController.swift
//  Proyecto_Bici
//
//  Created by macbook on 11/28/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    var username: String = ""
    var cuenta: String = ""
    var facu: String = ""

    @IBOutlet weak var usuiario: UILabel!
    @IBOutlet weak var Cuenta: UILabel!
    @IBOutlet weak var Facultad: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        usuiario.text = username
        Cuenta.text = cuenta
        Facultad.text = facu


    }
    
}
