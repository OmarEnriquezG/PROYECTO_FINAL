//
//  ModulosViewController.swift
//  Proyecto_Bici
//
//  Created by macbook  on 11/15/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit



class ModulosViewController: UIViewController, UITableViewDataSource, UITableViewDelegate{
    

    var modules = [modulos]()
    
  


    @IBOutlet weak var tabla: UITableView!
    var FromSecondView1 : String = ""
    var FromSecondView2 : Double = 0.0
    var FromSecondView3 : Double = 0.0


    override func viewDidLoad() {
        super.viewDidLoad()

        modules.append(modulos(nombre: "Universidad", latitude: 19.325203, longitude: -99.174788))
        modules.append(modulos(nombre: "Facultad de Ciencias", latitude: 19.325146, longitude: -99.178884))
        modules.append(modulos(nombre: "Anexo de Ingeniería", latitude: 19.327874, longitude: -99.182928))
        modules.append(modulos(nombre: "Facultad de Ingeniería", latitude: 19.332143, longitude: -99.184406))
        modules.append(modulos(nombre: "Faculdad de Arquitectura", latitude: 19.331494, longitude: -99.186708))
        modules.append(modulos(nombre: "Faculdad de Filosofía y letras", latitude: 19.333715, longitude: -99.186988))
        modules.append(modulos(nombre: "Faculdad de Derecho", latitude: 19.333717, longitude: -99.183884))
        modules.append(modulos(nombre: "Facultad de Medicina", latitude: 19.333524, longitude: -99.180846))
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return modules.count
    }
    
    func gradient(frame:CGRect) -> CAGradientLayer {
        let layer = CAGradientLayer()
        layer.frame = frame
        layer.startPoint = CGPoint(x: 0, y: 0.5)
        layer.endPoint = CGPoint(x: 1, y: 0.5)
        layer.colors = [UIColor.black.cgColor,UIColor.red.cgColor]
        return layer
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        
        cell.textLabel?.text = modules[indexPath.row].nombre
        cell.textLabel?.font = UIFont.systemFont(ofSize: 24.0)
        cell.textLabel?.textColor = UIColor.white;
        cell.layer.insertSublayer(gradient(frame: cell.bounds), at:0)
        cell.layer.borderColor = UIColor.red.cgColor
        cell.layer.borderWidth = 0
        cell.layer.cornerRadius = 4
        cell.clipsToBounds = true
    
        return cell
    }
    
        @IBAction func unwindSecondView(segue: UIStoryboardSegue){
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ThridView"{
            
            let indexPath = tabla.indexPathForSelectedRow
            let destination = segue.destination as! SecondMapViewController
            
            destination.FromFirstView4 = modules[(indexPath?.row)!].nombre
            destination.FromFirstView5 = modules[(indexPath?.row)!].latitude
            destination.FromFirstView6 = modules[(indexPath?.row)!].longitude
            destination.FromSecondView4 = FromSecondView1
            destination.FromSecondView5 = FromSecondView2
            destination.FromSecondView6 = FromSecondView3
    
    
        }}
            
}
            

