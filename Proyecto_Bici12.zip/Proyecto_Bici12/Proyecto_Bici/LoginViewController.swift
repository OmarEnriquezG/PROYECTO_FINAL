//
//  LoginViewController.swift
//  Proyecto_Bici
//
//  Created by macbook on 11/28/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    var username: String = ""

    @IBOutlet weak var usuiario: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        usuiario.text = username

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
