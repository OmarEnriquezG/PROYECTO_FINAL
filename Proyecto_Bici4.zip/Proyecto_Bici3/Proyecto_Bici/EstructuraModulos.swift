//
//  EstructuraModulos.swift
//  
//
//  Created by Usuario invitado on 22/11/18.
//

import Foundation


struct modulos {
    let nombre : String
    let latitude : Double
    let longitude : Double
}
