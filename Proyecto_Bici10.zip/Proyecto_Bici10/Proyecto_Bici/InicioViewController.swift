//
//  InicioViewController.swift
//  Proyecto_Bici
//
//  Created by macbook  on 11/30/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class InicioViewController: UIViewController , UITableViewDataSource, UITableViewDelegate{
    
    
    var modules1 = [modulos]()
    
    
    
    @IBOutlet weak var tabla: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        modules1.append(modulos(nombre: "Universidad", latitude: 19.325203, longitude: -99.174788))
        modules1.append(modulos(nombre: "Facultad de Ciencias", latitude: 19.325146, longitude: -99.178884))
        modules1.append(modulos(nombre: "Anexo de Ingeniería", latitude: 19.327874, longitude: -99.182928))
        modules1.append(modulos(nombre: "Facultad de Ingeniería", latitude: 19.332143, longitude: -99.184406))
        modules1.append(modulos(nombre: "Faculdad de Arquitectura", latitude: 19.331494, longitude: -99.186708))
        modules1.append(modulos(nombre: "Faculdad de Filosofía y letras", latitude: 19.333715, longitude: -99.186988))
        modules1.append(modulos(nombre: "Faculdad de Derecho", latitude: 19.333717, longitude: -99.183884))
        modules1.append(modulos(nombre: "Facultad de Medicina", latitude: 19.333524, longitude: -99.180846))
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return modules1.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        
        cell.textLabel?.text = modules1[indexPath.row].nombre
        cell.textLabel?.font = UIFont.systemFont(ofSize: 20.0)
        
        return cell
    }

@IBAction func unwindSecondView(segue: UIStoryboardSegue){
    
}

override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    if segue.identifier == "secondview"{
        
        let indexPath = tabla.indexPathForSelectedRow
        let destination = segue.destination as! MapViewController
        
        destination.FromFirstView = modules1[(indexPath?.row)!].nombre
        destination.FromFirstView2 = modules1[(indexPath?.row)!].latitude
        destination.FromFirstView3 = modules1[(indexPath?.row)!].longitude
        
        
    }}

}

