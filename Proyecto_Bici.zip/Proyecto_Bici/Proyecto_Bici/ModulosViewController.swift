//
//  ModulosViewController.swift
//  Proyecto_Bici
//
//  Created by macbook  on 11/15/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class ModulosViewController: UIViewController, UITableViewDataSource, UITableViewDelegate{
    
    var modules = ["Universidad","Facultad de Ciencias","Anexo de Ingeniería","Facultad de Ingenieria"]
    
    

    @IBOutlet weak var tabla: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return modules.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        
        cell.textLabel?.text = modules[indexPath.row]
        
        return cell
    }
    
    @IBOutlet weak var mapa: MKMapView!
    let locationManager = CLLocationManager()
    
    @IBAction func Aqui(_ sender: UIButton) {
        let annotation = CoffeeAnnotation()
        annotation.coordinate = CLLocationCoordinate2D(latitude: 19.327874, longitude: -99.182928)
        annotation.title = "Anexo de Ingeniería"
        annotation.subtitle = "Ciudad Universitaria"
        annotation.imageURL = "icono"
        
        mapa.addAnnotation(annotation)
    }
    
}
