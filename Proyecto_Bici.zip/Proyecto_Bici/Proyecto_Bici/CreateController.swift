//
//  CreateController.swift
//  Proyecto_Bici
//
//  Created by macbook  on 11/15/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class CreateController: UIViewController {
    @IBOutlet weak var Nombre: UITextField!
    
    @IBOutlet weak var Password: UITextField!
    @IBOutlet weak var Email: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func Crear(_ sender: Any) {
        
    }
    @IBAction func Back(_ sender: Any) {
         navigationController?.popViewController(animated: true)
    }
    
}
