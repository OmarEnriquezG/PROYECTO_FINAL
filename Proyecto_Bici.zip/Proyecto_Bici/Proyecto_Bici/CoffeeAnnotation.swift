//
//  CoffeeAnnotation.swift
//  Proyecto_Bici
//
//  Created by Usuario invitado on 20/11/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit
import MapKit

class CoffeeAnnotation: MKPointAnnotation {
    var imageURL :String!
}
