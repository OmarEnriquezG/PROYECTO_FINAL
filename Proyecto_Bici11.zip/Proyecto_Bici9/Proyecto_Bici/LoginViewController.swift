//
//  LoginViewController.swift
//  Proyecto_Bici
//
//  Created by macbook on 11/28/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    var username: String = ""
    var cuenta: String = ""

    @IBOutlet weak var usuiario: UILabel!
    @IBOutlet weak var Cuenta: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        usuiario.text = username
        Cuenta.text = cuenta


        // Do any additional setup after loading the view.
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
