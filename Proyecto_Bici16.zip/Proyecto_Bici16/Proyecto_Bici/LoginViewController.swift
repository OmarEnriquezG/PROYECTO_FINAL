//
//  LoginViewController.swift
//  Proyecto_Bici
//
//  Created by macbook on 11/28/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    var username: String = ""
    var facultad: String = ""

    @IBOutlet weak var facul: UILabel!
    @IBOutlet weak var usuiario: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        usuiario.text = username
    

       
    }
    

    
}
