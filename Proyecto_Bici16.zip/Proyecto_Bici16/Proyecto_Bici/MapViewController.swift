//
//  MapViewController.swift
//  Proyecto_Bici
//
//  Created by macbook  on 11/29/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import Firebase
import FirebaseFirestore

class MapViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {

    @IBOutlet weak var modulos: UILabel!
    
    @IBOutlet weak var NumeroBicis: UILabel!
    var FromFirstView : String = ""
    var FromFirstView2 : Double = 0.0
    var FromFirstView3 : Double = 0.0
    
    @IBOutlet weak var mapas: MKMapView!
    let locationManager = CLLocationManager()
    let annotation = Annotation()
    
    lazy var universidad : Int = 200
    lazy var xUniversidad = universidad as NSNumber
    lazy var xuniversidad : String = xUniversidad.stringValue
    
    
    lazy var ciencias : Int = 100
    lazy var xCiencias = ciencias as NSNumber
    lazy var xciencias : String = xCiencias.stringValue
    
    lazy var anexo : Int = 100
    lazy var xAnexo = anexo as NSNumber
    lazy var  xanexo : String = xAnexo.stringValue
    
    lazy var principal : Int = 100
    lazy var xPrincipal = principal as NSNumber
    lazy var xprincipal : String = xPrincipal.stringValue
    
    lazy var arquitectura : Int = 100
    lazy var xArquitectura = arquitectura as NSNumber
    lazy var xarquitectura : String = xArquitectura.stringValue
    
    lazy var filosofia : Int = 100
    lazy var xFilosofia = filosofia as NSNumber
    lazy var xfilosofia : String = xFilosofia.stringValue
    
    lazy var derecho : Int = 100
    lazy var xDerecho = derecho as NSNumber
    lazy var xderecho: String = xDerecho.stringValue
    
    lazy var medicina : Int = 100
    lazy var xMedicina = medicina as NSNumber
    lazy var xmedicina: String = xMedicina.stringValue
    
   
    
    @IBAction func decremento(_ sender: Any) {
        
        if FromFirstView == "Universidad"{
            universidad = universidad - 1
        
        }
        else if FromFirstView == "Facultad de Ciencias"{
            ciencias = ciencias - 1
        }
        else if FromFirstView == "Anexo de Ingeniería"{
            anexo = anexo - 1
        }
        else if FromFirstView == "Facultad de Ingeniería"{
            principal = principal - 1
        }
        else if FromFirstView == "Faculdad de Arquitectura"{
            arquitectura = arquitectura - 1
        }
        else if FromFirstView == "Faculdad de Filosofía y Letras"{
            filosofia = filosofia - 1
        }
        else if FromFirstView == "Faculdad de Derecho"{
            derecho = derecho - 1
        }
        else if FromFirstView == "Facultad de Medicina"{
            medicina = medicina - 1
        }
    }
     override func viewDidLoad() {
        super.viewDidLoad()

        
        
        
        
       modulos.text = FromFirstView
        annotation.title = FromFirstView
        annotation.subtitle = "Ciudad Universitaria"
        annotation.coordinate = CLLocationCoordinate2D(latitude: FromFirstView2, longitude: FromFirstView3 )
        annotation.imageURL = "icono"
        mapas.addAnnotation(annotation)
        mapas.delegate = self
        locationManager.delegate = self
        
        locationManager.requestWhenInUseAuthorization()
        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.distanceFilter = kCLDistanceFilterNone
        
        locationManager.startUpdatingLocation()
        mapas.showsUserLocation = true
    
        
        
        let inicioLocation = CLLocationCoordinate2D(latitude: 19.32751, longitude: -99.1823)
        let finLocation = CLLocationCoordinate2D(latitude: FromFirstView2, longitude: FromFirstView3)
        
        let sourcePlaceMark = MKPlacemark(coordinate: inicioLocation)
        let destinoPlaceMark = MKPlacemark(coordinate: finLocation)
        
        let directionRequest = MKDirections.Request()
        directionRequest.source = MKMapItem(placemark: sourcePlaceMark)
        directionRequest.destination = MKMapItem(placemark: destinoPlaceMark)
        directionRequest.transportType = .walking
        
        let directions = MKDirections(request: directionRequest)
        directions.calculate { (response, error) in
            guard let directionResponse = response else {
                if let error = error {
                    print ("Problema==\(error.localizedDescription)")
                }
                return
            }
            
            let route = directionResponse.routes[0]
            self.mapas.addOverlay(route.polyline)
            
            let rect = route.polyline.boundingMapRect
            self.mapas.setRegion(MKCoordinateRegion(rect), animated: true)
            
        }
        
        self.mapas.delegate = self
        
    
        let db = Firestore.firestore()
        if FromFirstView == "Universidad"{
            
            db.collection("modulos").document("universidad").setData(["universidad" : xuniversidad])
            db.collection("modulos").whereField("universidad", isEqualTo: xuniversidad).getDocuments { (snapshot, error) in
                if error != nil{
                    
                    print(error)
                    self.NumeroBicis.text = "error"
                }else {
                    for document in (snapshot?.documents)!{
                        let totalBicis = document.data()["universidad"]
                        self.NumeroBicis.text = (totalBicis as! String)
                    }
                }
            }
            
            
        }
            
            
            
        else if FromFirstView == "Facultad de Ciencias"{
            db.collection("modulos").document("Ciencias").setData(["Ciencias" : xciencias])
            db.collection("modulos").whereField("Ciencias", isEqualTo: xciencias).getDocuments { (snapshot, error) in
                if error != nil {
                    print(error)
                }else {
                    for document in (snapshot?.documents)!{
                        let totalBicis = document.data()["Ciencias"] as? String
                        self.NumeroBicis.text = totalBicis
                    }
                }
            }}
        else if FromFirstView == "Anexo de Ingeniería"{
            db.collection("modulos").document("Anexo").setData(["Anexo" : xanexo])
            db.collection("modulos").whereField("Anexo", isEqualTo: xanexo).getDocuments { (snapshot, error) in
                if error != nil {
                    print(error)
                }else {
                    for document in (snapshot?.documents)!{
                        let totalBicis = document.data()["Anexo"] as? String
                        self.NumeroBicis.text = totalBicis
                    }
                }
            }
            
        }
        else if FromFirstView == "Facultad de Ingeniería"{
            db.collection("modulos").document("Principal").setData(["Principal" : xprincipal])
            db.collection("modulos").whereField("Principal", isEqualTo: xprincipal).getDocuments { (snapshot, error) in
                if error != nil {
                    print(error)
                }else {
                    for document in (snapshot?.documents)!{
                        let totalBicis = document.data()["Principal"] as? String
                        self.NumeroBicis.text = totalBicis
                    }
                }
            }
            
        }
        else if FromFirstView == "Faculdad de Arquitectura"{
            db.collection("modulos").document("arquitectura").setData(["arquitectura" : xarquitectura])
            db.collection("modulos").whereField("arquitectura", isEqualTo: xarquitectura).getDocuments { (snapshot, error) in
                if error != nil {
                    print(error)
                }else {
                    for document in (snapshot?.documents)!{
                        let totalBicis = document.data()["arquitectura"] as? String
                        self.NumeroBicis.text = totalBicis
                    }
                }
            }
            
        }
        else if FromFirstView == "Faculdad de Filosofía y Letras"{
            db.collection("modulos").document("filosofia").setData(["filosofia" : xfilosofia])
            db.collection("modulos").whereField("filosofia", isEqualTo: xfilosofia).getDocuments { (snapshot, error) in
                if error != nil {
                    print(error)
                }else {
                    for document in (snapshot?.documents)!{
                        let totalBicis = document.data()["filosofia"] as? String
                        self.NumeroBicis.text = totalBicis
                    }
                }
            }
            
        }
        else if FromFirstView == "Faculdad de Derecho"{
            db.collection("modulos").document("derecho").setData(["derecho" : xderecho])
            db.collection("modulos").whereField("derecho", isEqualTo: xderecho).getDocuments { (snapshot, error) in
                if error != nil {
                    print(error)
                }else {
                    for document in (snapshot?.documents)!{
                        let totalBicis = document.data()["derecho"] as? String
                        self.NumeroBicis.text = totalBicis
                    }
                }
            }
            
        }
        else if FromFirstView == "Facultad de Medicina"{
            db.collection("modulos").document("medicina").setData(["medicina" : xmedicina])
            db.collection("modulos").whereField("medicina", isEqualTo: xmedicina).getDocuments { (snapshot, error) in
                if error != nil {
                    print(error)
                }else {
                    for document in (snapshot?.documents)!{
                        let totalBicis = document.data()["medicina"] as? String
                        self.NumeroBicis.text = totalBicis
                    }
                }
            }
            
        }
        
        
    }
    
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) ->MKOverlayRenderer {
        let renderer = MKPolylineRenderer(overlay: overlay)
        renderer.strokeColor = UIColor.brown
        renderer.lineWidth = 3.0
        return renderer
    }
    
    
    
    func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation) {
        let region =  MKCoordinateRegion(center: mapas.userLocation.coordinate, span: MKCoordinateSpan(latitudeDelta: 0.010, longitudeDelta: 0.010))
        
        mapas.setRegion(region, animated: true)
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]){
        print(locations.first)}
    
    @IBAction func unwindSecondView(segue: UIStoryboardSegue){
    
}

override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    if segue.identifier == "secondview2"{
        
      
        let dest = segue.destination as! ModulosViewController
        
        
        dest.FromSecondView1 = FromFirstView
        dest.FromSecondView2 = FromFirstView2
        dest.FromSecondView3 = FromFirstView3
        
    }}
    
}
