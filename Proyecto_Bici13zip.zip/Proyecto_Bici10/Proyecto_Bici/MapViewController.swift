//
//  MapViewController.swift
//  Proyecto_Bici
//
//  Created by macbook  on 11/29/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import Firebase
import FirebaseFirestore

class MapViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {

    @IBOutlet weak var modulos: UILabel!
    
    @IBOutlet weak var NumeroBicis: UILabel!
    var FromFirstView : String = ""
    var FromFirstView2 : Double = 0.0
    var FromFirstView3 : Double = 0.0
    
    @IBOutlet weak var mapas: MKMapView!
    let locationManager = CLLocationManager()
    let annotation = Annotation()
    override func viewDidLoad() {
        super.viewDidLoad()

        
        
        
        
       modulos.text = FromFirstView
        annotation.title = FromFirstView
        annotation.subtitle = "Ciudad Universitaria"
        annotation.coordinate = CLLocationCoordinate2D(latitude: FromFirstView2, longitude: FromFirstView3 )
        annotation.imageURL = "icono"
        mapas.addAnnotation(annotation)
        mapas.delegate = self
        locationManager.delegate = self
        
        locationManager.requestWhenInUseAuthorization()
        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.distanceFilter = kCLDistanceFilterNone
        
        locationManager.startUpdatingLocation()
        mapas.showsUserLocation = true
         let db = Firestore.firestore()
        if FromFirstView == "Universidad"{
            db.collection("moduloss").whereField("Universidad", isEqualTo: "200").getDocuments { (snapshot, error) in
                if error != nil {
                    print(error)
                }else {
                    for document in (snapshot?.documents)!{
                        let totalBicis = document.data()["Universidad"] as? String
                        self.NumeroBicis.text = totalBicis
                    }
                }
            }
          
        
        }
            else if FromFirstView == "Facultad de Ciencias"{
            db.collection("moduloss").whereField("Ciencias", isEqualTo: "101").getDocuments { (snapshot, error) in
                if error != nil {
                    print(error)
                }else {
                    for document in (snapshot?.documents)!{
                        let totalBicis = document.data()["Ciencias"] as? String
                        self.NumeroBicis.text = totalBicis
                    }
                }
            }}
        else if FromFirstView == "Anexo de Ingeniería"{
            db.collection("moduloss").whereField("Anexo", isEqualTo: "102").getDocuments { (snapshot, error) in
                if error != nil {
                    print(error)
                }else {
                    for document in (snapshot?.documents)!{
                        let totalBicis = document.data()["Anexo"] as? String
                        self.NumeroBicis.text = totalBicis
                    }
                }
            }
            
        }
        else if FromFirstView == "Facultad de Ingeniería"{
            db.collection("moduloss").whereField("Principal", isEqualTo: "103").getDocuments { (snapshot, error) in
                if error != nil {
                    print(error)
                }else {
                    for document in (snapshot?.documents)!{
                        let totalBicis = document.data()["Principal"] as? String
                        self.NumeroBicis.text = totalBicis
                    }
                }
            }
            
        }
        else if FromFirstView == "Faculdad de Arquitectura"{
            db.collection("moduloss").whereField("arqui", isEqualTo: "104").getDocuments { (snapshot, error) in
                if error != nil {
                    print(error)
                }else {
                    for document in (snapshot?.documents)!{
                        let totalBicis = document.data()["arqui"] as? String
                        self.NumeroBicis.text = totalBicis
                    }
                }
            }
            
        }
        else if FromFirstView == "Faculdad de Filosofía y Letras"{
            db.collection("moduloss").whereField("filos", isEqualTo: "105").getDocuments { (snapshot, error) in
                if error != nil {
                    print(error)
                }else {
                    for document in (snapshot?.documents)!{
                        let totalBicis = document.data()["filos"] as? String
                        self.NumeroBicis.text = totalBicis
                    }
                }
            }
            
        }
        else if FromFirstView == "Faculdad de Derecho"{
            db.collection("moduloss").whereField("derecho", isEqualTo: "106").getDocuments { (snapshot, error) in
                if error != nil {
                    print(error)
                }else {
                    for document in (snapshot?.documents)!{
                        let totalBicis = document.data()["derecho"] as? String
                        self.NumeroBicis.text = totalBicis
                    }
                }
            }
            
        }
        else if FromFirstView == "Facultad de Medicina"{
            db.collection("moduloss").whereField("medicina", isEqualTo: "107").getDocuments { (snapshot, error) in
                if error != nil {
                    print(error)
                }else {
                    for document in (snapshot?.documents)!{
                        let totalBicis = document.data()["medicina"] as? String
                        self.NumeroBicis.text = totalBicis
                    }
                }
            }
            
        }
        
        
        let inicioLocation = CLLocationCoordinate2D(latitude: 19.32751, longitude: -99.1823)
        let finLocation = CLLocationCoordinate2D(latitude: FromFirstView2, longitude: FromFirstView3)
        
        let sourcePlaceMark = MKPlacemark(coordinate: inicioLocation)
        let destinoPlaceMark = MKPlacemark(coordinate: finLocation)
        
        let directionRequest = MKDirections.Request()
        directionRequest.source = MKMapItem(placemark: sourcePlaceMark)
        directionRequest.destination = MKMapItem(placemark: destinoPlaceMark)
        directionRequest.transportType = .walking
        
        let directions = MKDirections(request: directionRequest)
        directions.calculate { (response, error) in
            guard let directionResponse = response else {
                if let error = error {
                    print ("Problema==\(error.localizedDescription)")
                }
                return
            }
            
            let route = directionResponse.routes[0]
            self.mapas.addOverlay(route.polyline)
            
            let rect = route.polyline.boundingMapRect
            self.mapas.setRegion(MKCoordinateRegion(rect), animated: true)
            
        }
        
        self.mapas.delegate = self
        
    }
    
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) ->MKOverlayRenderer {
        let renderer = MKPolylineRenderer(overlay: overlay)
        renderer.strokeColor = UIColor.brown
        renderer.lineWidth = 3.0
        return renderer
    }
    
    
    
    func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation) {
        let region =  MKCoordinateRegion(center: mapas.userLocation.coordinate, span: MKCoordinateSpan(latitudeDelta: 0.010, longitudeDelta: 0.010))
        
        mapas.setRegion(region, animated: true)
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]){
        print(locations.first)}
    
    @IBAction func unwindSecondView(segue: UIStoryboardSegue){
    
}

override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    if segue.identifier == "secondview2"{
        
      
        let dest = segue.destination as! ModulosViewController
        
        
        dest.FromSecondView1 = FromFirstView
        dest.FromSecondView2 = FromFirstView2
        dest.FromSecondView3 = FromFirstView3
        
    }}

 
    
}
