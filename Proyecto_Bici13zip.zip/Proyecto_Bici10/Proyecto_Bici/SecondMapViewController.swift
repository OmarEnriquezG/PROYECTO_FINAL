//
//  SecondMapViewController.swift
//  Proyecto_Bici
//
//  Created by macbook  on 11/30/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class SecondMapViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {
        @IBOutlet weak var mod: UILabel!
    @IBOutlet weak var mod2: UILabel!
    var FromFirstView4 : String = ""
    var FromFirstView5 : Double = 0.0
    var FromFirstView6 : Double = 0.0
    
    var FromSecondView4 : String = ""
    var FromSecondView5 : Double = 0.0
    var FromSecondView6 : Double = 0.0
    
    
    @IBOutlet weak var map: MKMapView!
    let locationManager = CLLocationManager()
    let annotation = Annotation()
    let annotation2 = Annotation()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        mod.text = FromFirstView4
        mod2.text = FromSecondView4
        annotation.title = FromFirstView4
        annotation.subtitle = "Ciudad Universitaria"
        annotation.coordinate = CLLocationCoordinate2D(latitude: FromFirstView5, longitude: FromFirstView6 )
        annotation.imageURL = "icono"
        map.addAnnotation(annotation)
        annotation2.title = FromSecondView4
        annotation2.subtitle = "Ciudad Universitaria"
        annotation2.coordinate = CLLocationCoordinate2D(latitude: FromSecondView5, longitude: FromSecondView6 )
        annotation2.imageURL = "icono"
        map.addAnnotation(annotation2)
        
        map.delegate = self
        locationManager.delegate = self
        
        locationManager.requestWhenInUseAuthorization()
        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.distanceFilter = kCLDistanceFilterNone
        
        locationManager.startUpdatingLocation()
        map.showsUserLocation = true
        
        
        
        let inicioLocation = CLLocationCoordinate2D(latitude: FromFirstView5, longitude: FromFirstView6)
        let finLocation = CLLocationCoordinate2D(latitude: FromSecondView5, longitude: FromSecondView6)
        
        let sourcePlaceMark = MKPlacemark(coordinate: inicioLocation)
        let destinoPlaceMark = MKPlacemark(coordinate: finLocation)
        
        let directionRequest = MKDirections.Request()
        directionRequest.source = MKMapItem(placemark: sourcePlaceMark)
        directionRequest.destination = MKMapItem(placemark: destinoPlaceMark)
        directionRequest.transportType = .walking
        
        let directions = MKDirections(request: directionRequest)
        directions.calculate { (response, error) in
            guard let directionResponse = response else {
                if let error = error {
                    print ("Problema==\(error.localizedDescription)")
                }
                return
            }
            
            let route = directionResponse.routes[0]
            self.map.addOverlay(route.polyline)
            
            let rect = route.polyline.boundingMapRect
            self.map.setRegion(MKCoordinateRegion(rect), animated: true)
            
        }
        
        self.map.delegate = self
        
    }
    
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) ->MKOverlayRenderer {
        let renderer = MKPolylineRenderer(overlay: overlay)
        renderer.strokeColor = UIColor.brown
        renderer.lineWidth = 3.0
        return renderer
    }
    
    
    func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation) {
        let region =  MKCoordinateRegion(center: map.userLocation.coordinate, span: MKCoordinateSpan(latitudeDelta: 0.010, longitudeDelta: 0.010))
        
        map.setRegion(region, animated: true)
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]){
        print(locations.first)}
    
}

