//
//  CoffeeAnnotation.swift
//  Holamapa
//
//  Created by Usuario invitado on 18/10/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit
import MapKit

class CoffeeAnnotation: MKPointAnnotation {
    var imageURL :String!
}
