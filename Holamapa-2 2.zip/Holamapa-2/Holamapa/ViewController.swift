//
//  ViewController.swift
//  Holamapa
//
//  Created by Usuario invitado on 16/10/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {

    @IBOutlet weak var mapTypeSegmentedControl: UISegmentedControl!
    @IBOutlet weak var mapa: MKMapView!
    let locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        mapa.delegate = self
        locationManager.delegate = self
        
        locationManager.requestWhenInUseAuthorization()
        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.distanceFilter = kCLDistanceFilterNone
        
        locationManager.startUpdatingLocation()
        mapa.showsUserLocation = true
        
        mapTypeSegmentedControl.addTarget(self, action: #selector(mapTypeChanged), for: .valueChanged)
    }
    
    @IBAction func addAnotation(_ sender: UIButton) {
        let annotation = CoffeeAnnotation()
        annotation.coordinate = CLLocationCoordinate2D(latitude: 19.327874, longitude: -99.182928)
        annotation.title = "Anexo de Ingeniería"
        annotation.subtitle = "Ciudad Universitaria"
        annotation.imageURL = "icono"
        
        mapa.addAnnotation(annotation)
    }
    
    
    @objc func mapTypeChanged( segmentedControl: UISegmentedControl){
        switch(segmentedControl.selectedSegmentIndex){
        case 0:
            mapa.mapType = .standard
        case 1:
            mapa.mapType = .satellite
        case 2:
            mapa.mapType = .hybrid
        default:
            mapa.mapType = .standard
        }
    }
    
    func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation) {
        let region =  MKCoordinateRegion(center: mapa.userLocation.coordinate, span: MKCoordinateSpan(latitudeDelta: 0.0009, longitudeDelta: 0.0009))
        
        mapa.setRegion(region, animated: true)
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]){
        print(locations.first)
    }
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        if annotation is MKUserLocation{
            return nil
        }
        
        var coffeAnnotationView = mapa.dequeueReusableAnnotationView(withIdentifier: "CoffeeAnnotationView")
        
        if coffeAnnotationView == nil{
            coffeAnnotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: "CoffeeAnnotationView")
            coffeAnnotationView?.canShowCallout = true
        }else{
            coffeAnnotationView?.annotation = annotation
        }
        
        if let coffeeAnnotation = annotation as? CoffeeAnnotation{
            coffeAnnotationView?.image = UIImage(named: coffeeAnnotation.imageURL)
        }
        return coffeAnnotationView
    }

}

