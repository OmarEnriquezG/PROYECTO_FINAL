//
//  Estructura.swift
//  Proyecto_Bici
//
//  Created by Laboratorio UNAM-Apple 02 on 27/11/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import Foundation

struct modulos {
    var nombre: String
    var latitude: Double
    var longitude: Double
}

