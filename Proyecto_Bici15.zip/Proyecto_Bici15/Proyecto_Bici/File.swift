//
//  File.swift
//  Proyecto_Bici
//
//  Created by MacBook on 12/3/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import Foundation
/* if FromFirstView == "Universidad"{
 NumeroBicis.text = "200"
 
 }
 else if FromFirstView == "Facultad de Ciencias"{
 NumeroBicis.text = "101"}
 else if FromFirstView == "Anexo de Ingeniería"{
 NumeroBicis.text = "102"
 }
 else if FromFirstView == "Facultad de Ingeniería"{
 NumeroBicis.text = "103"
 }
 else if FromFirstView == "Faculdad de Arquitectura"{
 NumeroBicis.text = "104"
 }
 else if FromFirstView == "Faculdad de Filosofía y Letras"{
 NumeroBicis.text = "105"
 }
 else if FromFirstView == "Faculdad de Derecho"{
 NumeroBicis.text = "106"
 }
 else if FromFirstView == "Facultad de Medicina"{
 NumeroBicis.text = "107"
 }
 */
