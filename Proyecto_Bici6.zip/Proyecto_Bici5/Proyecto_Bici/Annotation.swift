//
//  Annotation.swift
//  Proyecto_Bici
//
//  Created by macbook on 11/22/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit
import MapKit
class Annotation: MKPointAnnotation {
    var imageURL :String!

}
