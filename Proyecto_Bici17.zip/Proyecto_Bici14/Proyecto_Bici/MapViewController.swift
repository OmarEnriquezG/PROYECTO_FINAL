//
//  MapViewController.swift
//  Proyecto_Bici
//
//  Created by macbook  on 11/29/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class MapViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {

    @IBOutlet weak var modulos: UILabel!
    var FromFirstView : String = ""
    var FromFirstView2 : Double = 0.0
    var FromFirstView3 : Double = 0.0
    
    @IBOutlet weak var mapas: MKMapView!
    let locationManager = CLLocationManager()
    let annotation = Annotation()
    override func viewDidLoad() {
        super.viewDidLoad()

       modulos.text = FromFirstView
        annotation.title = FromFirstView
        annotation.subtitle = "Ciudad Universitaria"
        annotation.coordinate = CLLocationCoordinate2D(latitude: FromFirstView2, longitude: FromFirstView3 )
        annotation.imageURL = "icono"
        mapas.addAnnotation(annotation)
        mapas.delegate = self
        locationManager.delegate = self
        
        locationManager.requestWhenInUseAuthorization()
        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.distanceFilter = kCLDistanceFilterNone
        
        locationManager.startUpdatingLocation()
        mapas.showsUserLocation = true
        
        
        
    }
    
    
    
    func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation) {
        let region =  MKCoordinateRegion(center: mapas.userLocation.coordinate, span: MKCoordinateSpan(latitudeDelta: 0.010, longitudeDelta: 0.010))
        
        mapas.setRegion(region, animated: true)
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]){
        print(locations.first)}
    
}
