//
//  LoginViewController.swift
//  Proyecto_Bici
//
//  Created by macbook on 11/28/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit
import Firebase

class LoginViewController: UIViewController {
    var username: String = ""
    var cuenta: String = ""
    //var facu: String = ""

    @IBOutlet weak var usuiario: UILabel!
    @IBOutlet weak var Cuenta: UILabel!
    @IBOutlet weak var Facultad: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let db = Firestore.firestore()
        //let facu: String = ""
        db .collection("users").getDocuments {(snapshot, error) in
            if error != nil {
                print(error)
            } else {
                for document in (snapshot?.documents)! {
                    
                    if let facultad = document.data()["facultad"] as? String {
                        //self.Facultad.text = facultad
                        print(facultad)
                        if let correo2 = document.data()["correo"] as? String {
                            print(correo2)
                            if correo2 == self.username{
                                self.Facultad.text = facultad
                            }
                        }
                    }
                }
            }
        }

        usuiario.text = username
        Cuenta.text = cuenta
        //Facultad.text = facu


    }
    
}
